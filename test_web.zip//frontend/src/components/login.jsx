import React, { useState } from "react";
import "./LoginSignup.css";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    // Handle login logic here
    console.log("Logging in:", email, password);
  };

  return (
    <div className="login-container">
      <div className="login-form">
        <img src="logo.png" alt="MyEasyPharma Logo" className="logo" />
        <h2>Log in</h2>
        <p>
          Don’t have an account? <a href="/signup">Sign up</a>
        </p>

        <button className="social-login facebook">Log in with Facebook</button>
        <button className="social-login google">Log in with Google</button>

        <hr />

        <form onSubmit={handleLogin}>
          <label>Email or Username</label>
          <input
            type="text"
            placeholder="Email or Username"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />

          <label>Password</label>
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />

          <a href="/forgot-password">Forgot your password?</a>
          <button type="submit" className="login-btn">
            Log in
          </button>
        </form>
      </div>
      <div className="login-image">
        <img src="/yoga-image.png" alt="Yoga" />
      </div>
    </div>
  );
};

export default Login;
