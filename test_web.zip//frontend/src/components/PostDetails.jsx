import React from "react";
import { useParams } from "react-router-dom";

const PostDetails = ({ posts }) => {
  const { postId } = useParams(); // Get post ID from the URL
  const post = posts.find((p) => p.id === parseInt(postId));

  if (!post) {
    return <div>Post not found</div>;
  }

  return (
    <div className="post-details">
      <h2>{post.author}</h2>
      <p>{post.timestamp}</p>
      <p>{post.content}</p>
      {post.images.length > 0 && (
        <img src={URL.createObjectURL(post.images[0])} alt="Post image" />
      )}
    </div>
  );
};

export default PostDetails;
