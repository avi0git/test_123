// src/components/Header.jsx
import React from "react";
import "../styles/Header.css";

function Header({ toggleChat, addNewPost, openSignUp }) {
  return (
    <header className="header">
      <h1>Post App</h1>
      <div className="header__buttons">
        <button className="header__button" onClick={addNewPost}>
          New Post
        </button>
        <button className="header__button" onClick={toggleChat}>
          Messages
        </button>
        <button className="header__button" onClick={openSignUp}>
          Sign Up
        </button>
      </div>
    </header>
  );
}

export default Header;
