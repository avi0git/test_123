import React from "react";
import axios from "axios";
import Sidebar from "../components/Sidebar";
import Post from "../components/Post";
import "../styles/HomePage.css";

const HomePage = () => {
  const [posts, setPosts] = useState([]);

  useEffect(() => {
    const fetchPosts = async () => {
      try {
        const response = await axios.get("/api/posts");
        setPosts(response.data); // Set the fetched posts
      } catch (error) {
        console.error(
          "Error fetching posts:",
          error.response?.data?.message || error.message
        );
      }
    };

    fetchPosts();
  }, []);

  return (
    <div className="homepage">
      <Sidebar />
      <div className="homepage__content">
        {posts.map((post) => (
          <Post key={post.id} post={post} />
        ))}
      </div>
    </div>
  );
};

export default HomePage;
