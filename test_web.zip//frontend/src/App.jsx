import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Post from "./components/Post";
import NewPostModal from "./components/NewPostModal";
import Chat from "./components/Chat";
import PostDetails from "./components/PostDetails"; // Assuming you have a PostDetails component
import SignUpForm from "./components/SignUpForm"; // Import the SignUp form
import "./styles/App.css"; // Assuming CSS is handled globally

const App = () => {
  const [posts, setPosts] = useState([
    {
      id: 1,
      author: "MyEasyPharma",
      timestamp: "2 hours ago",
      content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit...",
      upvotes: 89,
      comments: [],
      upvoted: false,
      images: [],
    },
    {
      id: 2,
      author: "MyEasyPharma",
      timestamp: "4 hours ago",
      content: "Another example post content here...",
      upvotes: 56,
      comments: [],
      upvoted: false,
      images: [],
    },
  ]);

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [isSignUpModalOpen, setIsSignUpModalOpen] = useState(false); // Sign Up Modal State
  const [isLoggedIn, setIsLoggedIn] = useState(false); // Track login status

  // Function to handle a new post creation
  const handleNewPost = (content, images) => {
    const newPost = {
      id: posts.length + 1,
      author: "MyEasyPharma",
      timestamp: "Just now",
      content,
      upvotes: 0,
      comments: [],
      upvoted: false,
      images, // store multiple images
    };
    setPosts([newPost, ...posts]);
    setIsModalOpen(false); // Close modal after saving
  };

  // Function to handle adding a comment
  const handleAddComment = (postId, commentText) => {
    const updatedPosts = posts.map((post) => {
      if (post.id === postId) {
        return {
          ...post,
          comments: [
            ...post.comments,
            { id: post.comments.length + 1, text: commentText },
          ],
        };
      }
      return post;
    });
    setPosts(updatedPosts);
  };

  // Handle logout
  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <div className={`app ${isChatOpen ? "app--split" : ""}`}>
        <header className="app__header">
          <h1>NewsFeed</h1>
          <div className="buttons">
            <button
              className="new-post-button"
              onClick={() => setIsModalOpen(true)}
            >
              New Post
            </button>
            <button
              className="messages-button"
              onClick={() => setIsChatOpen(!isChatOpen)}
            >
              Messages
            </button>

            {/* Conditional rendering for Sign Up or Logout */}
            {!isLoggedIn ? (
              <button
                className="signup-button"
                onClick={() => setIsSignUpModalOpen(true)}
              >
                Sign Up
              </button>
            ) : (
              <button className="logout-button" onClick={handleLogout}>
                Logout
              </button>
            )}
          </div>
        </header>
        <main className="app__main">
          <Routes>
            {/* Home route to show all posts */}
            <Route
              path="/"
              element={
                <div className="posts__container">
                  {posts.map((post) => (
                    <Post
                      key={post.id}
                      post={post}
                      onAddComment={handleAddComment}
                    />
                  ))}
                </div>
              }
            />
            {/* Route to show individual post */}
            <Route
              path="/post/:postId"
              element={<PostDetails posts={posts} />}
            />
          </Routes>
        </main>
        <footer className="app__footer">
          <p>© 2024 MyEasyPharma. All rights reserved.</p>
          <p>
            <a href="#">Terms of Service</a> • <a href="#">Privacy Policy</a> •{" "}
            <a href="#">Contact Us</a>
          </p>
        </footer>

        {/* Modal for creating a new post */}
        {isModalOpen && (
          <NewPostModal
            onClose={() => setIsModalOpen(false)}
            onSave={handleNewPost}
          />
        )}

        {/* Modal for Sign Up */}
        {isSignUpModalOpen && (
          <SignUpForm
            onSignUpComplete={() => {
              setIsLoggedIn(true); // Mark user as logged in
              setIsSignUpModalOpen(false); // Close the sign-up modal
            }}
            onClose={() => setIsSignUpModalOpen(false)} // Handle close modal
          />
        )}

        {/* Chat window */}
        {isChatOpen && <Chat onClose={() => setIsChatOpen(false)} />}
      </div>
    </Router>
  );
};

export default App;
