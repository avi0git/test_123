const Post = require("../models/postModel");

// Get all posts
exports.getAllPosts = async (req, res) => {
  try {
    const posts = await Post.find().sort({ createdAt: -1 });
    res.status(200).json(posts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Create a new post
exports.createPost = async (req, res) => {
  const { author, content, images } = req.body;
  try {
    const newPost = new Post({ author, content, images });
    await newPost.save();
    res.status(201).json(newPost);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Upvote a post
exports.upvotePost = async (req, res) => {
  const { id } = req.params;
  try {
    const post = await Post.findById(id);
    post.upvotes += 1;
    await post.save();
    res.status(200).json(post);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Add a comment
exports.addComment = async (req, res) => {
  const { id } = req.params;
  const { commentText } = req.body;
  try {
    const post = await Post.findById(id);
    post.comments.push({ text: commentText });
    await post.save();
    res.status(201).json(post);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
