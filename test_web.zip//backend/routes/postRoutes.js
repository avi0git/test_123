const express = require("express");
const router = express.Router();
const postController = require("../controllers/postController");

// Routes for post operations
router.get("/", postController.getAllPosts);
router.post("/", postController.createPost);
router.post("/:id/upvote", postController.upvotePost);
router.post("/:id/comment", postController.addComment);

module.exports = router;
